<?php

/**
 * @author SAPSAN 隼 #3604
 *
 * @link https://hlmod.ru/members/sapsan.83356/
 * @link https://github.com/sapsanDev
 *
 * @license GNU General Public License Version 3
 */

namespace app\modules\module_page_lk_impulse\ext;

class Lk_module
{
    public $name;
    public $Modules;
    public $General;
    public $Db;
    public $Notifications;

    public function __construct($Translate, $Notifications, $General, $Modules, $Db)
    {
        $this->Modules = $Modules;
        $this->Translate = $Translate;
        $this->General = $General;
        $this->db = $Db;
        $this->Notifications = $Notifications;

        $this->checkCallback();

    }

    public function LkBalancePlayer()
    {
        if (isset($_SESSION['steamid32'])) {
            preg_match('/:[0-9]{1}:\d+/i', $_SESSION['steamid32'], $auth);
            $param = [
                'auth'  => '%' . $auth[0] . '%'
            ];
            if ($this->db->db_data['lk'][0]['mod'] == 1) {
                $infoUser = $this->db->queryAll('lk', 0, 0, "SELECT `cash` FROM `lk` WHERE `auth` LIKE :auth LIMIT 1", $param);
                $cash = 'cash';
            } else if ($this->db->db_data['lk'][0]['mod'] == 2) {
                $infoUser = $this->db->queryAll('lk', 0, 0, "SELECT `money` FROM `lk_system` WHERE `auth` LIKE :auth LIMIT 1", $param);
                $cash = 'money';
            }
            $this->Modules->set_user_info_text(
                $this->Translate->get_translate_module_phrase('module_page_pay', '_Balance') .
                    ': ' .
                    $this->Translate->get_translate_module_phrase('module_page_pay', '_AmountCourse') .
                    ' <b class="material-balance">' .
                    number_format($infoUser[0][$cash], 0, ' ', ' ') .
                    '</b>'
            );
            return number_format($infoUser[0][$cash], 0, ' ', ' ');
        }
    }

    public function LkAllDonats()
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if ($this->db->db_data['lk'][0]['mod'] == 1)
            $allDonat = $this->db->queryNum('lk', 0, 0, "SELECT SUM(`all_cash`) FROM `lk` LIMIT 1");
        elseif ($this->db->db_data['lk'][0]['mod'] == 2)
            $allDonat = $this->db->queryNum('lk', 0, 0, "SELECT SUM(`all_money`) FROM `lk_system` LIMIT 1");
        return number_format($allDonat[0], 0, ' ', ' ');
    }

    public function LkAllDonatsToPayGateway($system)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $params = ['name' => $system];
        $cashSYS = $this->db->queryNum('lk', 0, 0, "SELECT SUM(`pay_summ`) FROM `lk_pays` WHERE `pay_system` = :name AND `pay_status` = 1 LIMIT 1", $params);
        if (empty($cashSYS))
            return false;
        return number_format($cashSYS[0], 0, ' ', ' ');
    }

    public function LkLogs()
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $alllogs = $this->db->queryAll('lk', 0, 0, "SELECT DISTINCT `log_name` FROM `lk_logs`");
        return array_reverse($alllogs);
    }

    public function LkLogContent($log)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (!preg_match('/^[0-9]{2}\_[0-9]{2}\_[0-9]{4}+$/i', $log))
            return [0 => ['log_name' => $log, 'log_time' => ' ', 'log_content' => '_Error']];
        $param = ['log_name' => $log];
        $contentLog = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_logs` WHERE `log_name` = :log_name", $param);
        if (!empty($contentLog))
            return $contentLog;
        else
            return [0 => ['log_name' => $log, 'log_time' => ' ', 'log_content' => '_LogNotFound']];
    }

    public function LkLogdelete($log)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (!preg_match('/^[0-9]{2}\_[0-9]{2}\_[0-9]{4}+$/i', $log))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        $param = ['log_name' => $log];
        $this->db->query('lk', 0, 0, "DELETE FROM `lk_logs` WHERE `log_name` = :log_name", $param);
        $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_LogDeleted'), 'success');
    }

    public function LkDownloadLog($log)
    {
        if (ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
        if (preg_match('/^[0-9]{2}\_[0-9]{2}\_[0-9]{4}+$/i', $log)) {
            $param = [
                'log_name' => $log
            ];
            $logs = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_logs` WHERE `log_name` = :log_name", $param);
            $logFileHandle = fopen('storage/cache/sessions/' . $log . '.log', 'a');
            foreach ($logs as $key) {
                fwrite(
                    $logFileHandle,
                    $key['log_name'] . $key['log_time'] . LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', $key['log_content']), json_decode(str_replace('[]', '', $key['log_value']), true)) . "\r\n"
                );
            }
            fclose($logFileHandle);
        } else {
            return false;
        }
        if (empty($log)) {
            return false;
        } else if (!file_exists('storage/cache/sessions/' . $log . '.log')) {
            return false;
        }
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private", false);
        header("Content-Type: storage/cache/sessions/");
        header("Content-Disposition: attachment; filename=\"" . basename($log . '.log') . "\";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: " . filesize('storage/cache/sessions/' . $log . '.log'));
        readfile('storage/cache/sessions/' . $_POST['log_download'] . '.log');
        unlink('storage/cache/sessions/' . $log . '.log');
        exit();
    }

    public function LkPromocodes()
    {
        $allcodes = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_promocodes`");
        return $allcodes;
    }

    public function LkPromoCode($id)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $param = [
            'id' => $id
        ];
        $code = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_promocodes` WHERE `id` = :id LIMIT 1", $param);
        return $code;
    }

    public function LkDiscordData()
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $DiscordData = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_discord` LIMIT 1");
        return $DiscordData[0];
    }

    public function LkGetAllGateways()
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $allGateways = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pay_service`");
        return $allGateways;
    }

    public function LkGetGateway($gateway)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $param = ['id' => $this->LkConvertGatewayId($gateway)];
        $Gateway = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pay_service` WHERE `id` = :id", $param);
        return $Gateway;
    }

    public function LkGetGatewaysOn()
    {
        $allKass = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pay_service` WHERE `status` = 1");
        return $allKass;
    }

    public function LkGetGatewayOn($gateway)
    {
        $param = ['id' => $this->LkConvertGatewayId($gateway)];
        $gatewayExist = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pay_service` WHERE `status` = 1 AND `id` = :id", $param);
        return $gatewayExist;
    }

    public function LkGetUserData($user)
    {
        if (!preg_match('/^STEAM_[0-9]{1,2}:[0-1]:\d+$/', $user)) return false;
        $param = [
            'auth'  => $user
        ];
        if ($this->db->db_data['lk'][0]['mod'] == 1)
            $userdata = $this->db->query('lk', 0, 0, "SELECT * FROM `lk` WHERE `auth`  = :auth LIMIT 1", $param);
        else if ($this->db->db_data['lk'][0]['mod'] == 2)
            $userdata = $this->db->query('lk', 0, 0, "SELECT * FROM `lk_system` WHERE `auth` = :auth LIMIT 1", $param);
        return $userdata;
    }

    public function LkGetUserPays($user)
    {
        if (!preg_match('/^STEAM_[0-9]{1,2}:[0-1]:\d+$/', $user)) return false;
        $param = [
            'auth'  => $user
        ];
        $userdata = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pays` WHERE `pay_auth` = :auth ORDER BY `pay_id` DESC", $param);
        return $userdata;
    }

    public function LkGetAllPays()
    {
        $pays = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pays` ORDER BY `pay_id` DESC");
        return $pays;
    }

    public function LkGetAllPlayers($min, $max)
    {
        if ($this->db->db_data['lk'][0]['mod'] == 1)
            return $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk` ORDER BY `all_cash` DESC LIMIT $min, $max");
        else if ($this->db->db_data['lk'][0]['mod'] == 2)
            return $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_system` ORDER BY `all_money` DESC LIMIT $min, $max");
    }

    public function UsersPageMax($max)
    {
        $param = ['max' => $max];
        if ($this->db->db_data['lk'][0]['mod'] == 1)
            return ceil($this->db->queryNum('lk', 0, 0, "SELECT COUNT(*) FROM `lk` LIMIT 1")[0] / $max);
        else if ($this->db->db_data['lk'][0]['mod'] == 2)
            return ceil($this->db->queryNum('lk', 0, 0, "SELECT COUNT(*) FROM `lk_system` LIMIT 1")[0] / $max);
    }

    public function LkUsagePromo($promo)
    {
        if (!preg_match('/^[A-z-0-9]{5,15}$/', $promo)) return false;
        $param = [
            'pay_promo' => $promo
        ];
        $promoData = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pays` WHERE `pay_promo`  = :pay_promo AND `pay_status` = 1  ORDER BY `pay_id` DESC", $param);
        return $promoData;
    }

    public function LkAddPromocode($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (empty($post['addpromo']))
            $promo = substr(str_shuffle('1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, rand(5, 15));
        else
            $promo = $post['addpromo'];
        if (!preg_match('/^[A-z-0-9]{5,15}$/', $promo))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ErrorNamePromo'), 'error');
        else if (empty($post['limit']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_LimitPromo'), 'error');
        else if (!preg_match('/^\d+$/', $post['limit']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_LimitField'), 'error');
        else if (empty($post['bonuspecent']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_EnterBonus'), 'error');
        else if (!preg_match('/^[0-9\.]+$/', $post['bonuspecent']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_NotCorBonus'), 'error');
        $param = ['code' => $promo];
        $expromo = $this->db->queryAll('lk', 0, 0, "SELECT `code` FROM `lk_promocodes` WHERE `code` = :code", $param);
        if (!empty($expromo))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ExistPromo'), 'error');
        if (empty($post['status']))
            $auth = 0;
        else $auth = 1;
        $params = [
            'code' => $promo,
            'attempts' => $post['limit'],
            'percent' => $post['bonuspecent'],
            'auth' => $auth,
        ];
        $this->db->query('lk', 0, 0, "INSERT INTO `lk_promocodes` (`code`, `percent`, `attempts`, `auth1`) VALUES(:code, :percent, :attempts, :auth)", $params);
        $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_AddedPromo'), ['namepromo' => $promo]), 'success');
    }

    public function LkEditPromocode($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (empty($post['editid']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        elseif (!preg_match('/^\d+$/', $post['editid']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        elseif (empty($post['editpromo']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_EditPromoName'), 'error');
        elseif (!preg_match('/^[A-z-0-9]{5,15}$/', $post['editpromo']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ErrorNamePromo'), 'error');
        elseif (empty($post['editlimit']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_LimitPromo'), 'error');
        elseif (!preg_match('/^\d+$/', $post['editlimit']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_LimitField'), 'error');
        elseif (empty($post['editbonuspecent']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_EnterBonus'), 'error');
        elseif (!preg_match('/^[0-9\.]+$/', $post['editbonuspecent']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_NotCorBonus'), 'error');
        elseif (empty($post['status']))
            $auth = 0;
        else
            $auth = 1;
        $param = [
            'id' => $post['editid']
        ];
        $expromo = $this->db->queryAll('lk', 0, 0, "SELECT `id` FROM `lk_promocodes` WHERE `id` = :id LIMIT 1", $param);
        if (empty($expromo))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        $params = [
            'id'        => $post['editid'],
            'code'      => $post['editpromo'],
            'attempts'  => $post['editlimit'],
            'percent'   => $post['editbonuspecent'],
            'auth'      => $auth,
        ];
        $this->db->query('lk', 0, 0, "UPDATE `lk_promocodes` SET `code` = :code, `percent` = :percent, `attempts` = :attempts, `auth1` = :auth WHERE `id` = :id LIMIT 1", $params);
        $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_EditedPromo'), ['namepromo' => $post['editpromo']]), 'success');
    }

    public function LkDeletePromocode($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true)  exit();
        if (empty($post['promocode_delete']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        else if (!preg_match('/^\d+$/', $post['promocode_delete']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        $param = [
            'id'    => $post['promocode_delete']
        ];
        $expromo = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_promocodes` WHERE `id` = :id LIMIT 1", $param);
        if (empty($expromo))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        $this->db->query('lk', 0, 0, "DELETE FROM `lk_promocodes` WHERE `id` = :id LIMIT 1", $param);
        $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_DeletedPromo'), 'success');
    }

    public function LkAddDiscord($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (empty($post['webhoock_url_offon'])) {
            $auth = 0;
        } else {
            if (empty($post['webhoock_url']))
                $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_EnterWebhoockUrl'), 'error');
            $auth = 1;
        }
        $param = [
            'url'   => $post['webhoock_url'],
            'auth'  => $auth
        ];
        $allGateways = $this->db->query('lk', 0, 0, "UPDATE `lk_discord` SET `url` = :url, `auth` = :auth", $param);
        $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Saved'), 'success');
    }

    public function LkAddGateway($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $this->LkExistGatewayAdd($post);
        $this->LKvalidateGatewayData($post['gateway'], $post);
        $params = [
            'id' => $this->LkConvertGatewayId($post['gateway']),
            'name' => $this->name,
        ];
        $this->db->query('lk', 0, 0, "INSERT INTO `lk_pay_service` VALUES(:id, :name, '$post[shopid]', '$post[secret1]', '$post[secret2]', 1)", $params);
        $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_AddGateway'), ['name' => $this->name]), 'success');
    }

    public function LkEditGateway($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (isset($_POST['status']))
            $status = 1;
        else
            $status = 0;
        $this->LkNotExistGateway($post['gateway_edit']);
        $this->LKvalidateGatewayData($post['gateway_edit'], $post);
        $params = [
            'id'        => $this->LkConvertGatewayId($post['gateway_edit']),
            'status'    => $status,
        ];
        $this->db->query('lk', 0, 0, "UPDATE `lk_pay_service` SET `shop_id` = '$post[shopid]', `secret_key_1` = '$post[secret1]', `secret_key_2` = '$post[secret2]', `status` = :status WHERE `id` = :id LIMIT 1", $params);
        $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_DataChangesGateway'), ['gateway' => $this->name]), 'success');
    }

    public function LkDeleteGateway($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (!preg_match('/^\d+$/i', $post['gateway_delete']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_Error'), 'error');
        $this->LkNotExistGateway($this->LkConvertGatewayString($post['gateway_delete']));
        $param = [
            'id'    => $post['gateway_delete']
        ];
        $this->db->query('lk', 0, 0, "DELETE FROM `lk_pay_service` WHERE `id` = $param[id] LIMIT 1");
        $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_DeletedGateway'), 'success');
    }

    public function LkNotExistGateway($gateway)
    {
        $param = [
            'id'    => $this->LkConvertGatewayId($gateway)
        ];
        $gateway = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pay_service` WHERE `id` = :id LIMIT 1", $param);
        
        if (empty($gateway))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_GetwNoExist'), 'error');
    }

    protected function LkExistGatewayAdd($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $param = [
            'id'    => $this->LkConvertGatewayId($post['gateway'])
        ];
        $gateway = $this->db->queryAll('lk', 0, 0, "SELECT `id` FROM `lk_pay_service` WHERE `id` = :id LIMIT 1", $param);
        if (!empty($gateway))
            $this->message($this->name . $this->Translate->get_translate_module_phrase('module_page_pay', '_GetwExist'), 'error');
    }

    protected function LKvalidateGatewayData($gateway, $post)
    {
        switch ($gateway) {
			case 'cshost_liqpay':
				if(empty($post['shopid']))
					$this->message($this->Translate->get_translate_module_phrase('module_page_pay','_ISID'), 'error');
				else if(empty($post['secret1']))
					$this->message($this->Translate->get_translate_module_phrase('module_page_pay','_ISEC').' #1', 'error');
				$this->name = 'cshost_liqpay';
			break;
			case 'cshost_p2p':
				if(empty($post['shopid']))
					$this->message($this->Translate->get_translate_module_phrase('module_page_pay','_ISID'), 'error');
				else if(empty($post['secret1']))
					$this->message($this->Translate->get_translate_module_phrase('module_page_pay','_ISEC').' #1', 'error');
				$this->name = 'cshost_p2p';
			break;
            case 'freekassa':
                if (empty($post['shopid']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISID'), 'error');
                else if (empty($post['secret1']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISEC') . ' #1', 'error');
                else if (empty($post['secret2']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISEC') . ' #2', 'error');
                $this->name = 'FreeKassa';
                break;
            case 'skinpay':
                if (empty($post['shopid']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISID'), 'error');
                else if (empty($post['secret1']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISEC') . ' #1', 'error');
                $this->name = 'SkinPay';
                break;
            case 'skinsback':
                if (empty($post['shopid']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISID'), 'error');
                else if (empty($post['secret1']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISEC') . ' #1', 'error');
                $this->name = 'SkinsBack';
                break;
            case 'centapp':
                if (empty($post['shopid']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISID'), 'error');
                else if (empty($post['secret1']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISEC') . ' #1', 'error');
                $this->name = 'CentAPP';
                break;
            case 'paypalych':
                if (empty($post['shopid']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISID'), 'error');
                else if (empty($post['secret1']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISEC') . ' #1', 'error');
                $this->name = 'PayPalych';
                break;  
            case 'yandexmoney':
                if (empty($post['shopid']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_IPURSE'), 'error');
                else if (empty($post['secret2']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ISEC'), 'error');
                $this->name = 'YandexMoney';
                break;
            case 'paypal':
                if (empty($post['shopid']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_EnterPaypalAccount'), 'error');
                $this->name = 'PayPal';
                break;
            case 'qiwi':
                if (empty($post['secret1']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_InPub'), 'error');
                else if (empty($post['secret2']))
                    $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_InSec'), 'error');
                $this->name = 'Qiwi';
                break;
            case 'foxypay':
                $this->name = 'FoxyPay';
                break;
            default:
                $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_NINT'), 'error');
                break;
        }
    }

    public function status($status)
    {
        if (empty($status))
            $return = '<a style="color:#d61a1a;">-</a>';
        else
            $return = '<a style="color:#18b518;">+</a>';
        return $return;
    }

    public function LkDelUsers()
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if ($this->db->db_data['lk'][0]['mod'] == 1)
            $this->db->query('lk', 0, 0, "DELETE FROM `lk` WHERE !cash AND `all_cash` = 0");
        else if ($this->db->db_data['lk'][0]['mod'] == 2)
            $this->db->query('lk', 0, 0, "DELETE FROM `lk_system` WHERE !money AND `all_money` = 0");
        $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_UsersDelete'), 'success');
    }

    public function LkUpdateBalance($post)
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        if (!preg_match('/^STEAM_[0-9]{1,2}:[0-1]:\d+$/', $post['user']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_SteamError'), 'error');
        if (!preg_match('/^[0-9]{1,5}.[0-9]{1,2}$/', $this->WM($post['new_balance'])))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_AmountError'), 'error');
        $new_balance = $post['new_balance'] - $post['old_balance'];
        if ($new_balance != 0) {
            $params = [
                'order'     => time() % 100000,
                'auth'      => $post['user'],
                'summ'      => $new_balance,
                'data'      => date('d.m.Y \в H:i:s'),
                'system'    => 'Admin'
            ];
            $this->db->query(
                'lk',
                0,
                0,
                "INSERT INTO `lk_pays` (`pay_order`, `pay_auth`, `pay_summ`, `pay_data`, `pay_system`, `pay_promo`, `pay_status`) VALUES($params[order], '$params[auth]', $params[summ], '$params[data]', '$params[system]', '', 1)"
            );
            $this->Notifications->SendNotification($post['user'], "Пополнение", "Вам Администратор пополнил баланс на <a>" . $new_balance . " ₴</a>", "/pay/", "pay");
        }
        $_SESSION['pay_balance'] = $new_balance;
        $params = [
            'auth'  => $post['user'],
            'cash'  => $post['new_balance'],
        ];
        if ($this->db->db_data['lk'][0]['mod'] == 1) {
            $this->db->query('lk', 0, 0, "UPDATE `lk` SET `cash` = :cash WHERE `auth` = :auth LIMIT 1", $params);
        } else if ($this->db->db_data['lk'][0]['mod'] == 2) {
            $this->db->query('lk', 0, 0, "UPDATE `lk_system` SET `money` = :cash WHERE `auth` = :auth LIMIT 1", $params);
        }
        $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_NewBalanceUser'), ['user' => $post['user']]), 'success');
    }

    public function LkCleanLogs()
    {
        if (!isset($_SESSION['user_admin']) || IN_LR != true) exit();
        $mouth = date('m_Y');
        $expromo = $this->db->query('lk', 0, 0, "DELETE FROM `lk_logs` WHERE `log_name` NOT LIKE '%$mouth%'");
        $this->message('Логи очищены!' . $mouth, 'success');
    }

    public function LkLoadPlayerProfile($link, $type = 0)
    {
        $_SAPIKEY = $this->General->arr_general['web_key'];
        $match = explode('/', $link);
        if (!empty($match[4])) {
            if (preg_match('/^(7656119)([0-9]{10})$/', $match[4])) {
                $get = $this->CurlSend("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" . $_SAPIKEY . "&steamids=" . $match[4]);
                $content = json_decode($get, true);
            } else {
                $get = $this->CurlSend("http://api.steampowered.com/ISteamUser/ResolveVanityURL/v0001/?key=" . $_SAPIKEY . "&vanityurl=" . $match[4]);
                $castomName = json_decode($get, true);
                $get = $this->CurlSend("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" . $_SAPIKEY . "&steamids=" . $castomName['response']['steamid']);
                $content = json_decode($get, true);
            }
        } else if (preg_match('/^(7656119)([0-9]{10})$/', $link)) {
            $get = $this->CurlSend("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" . $_SAPIKEY . "&steamids=" . $link);
            $content = json_decode($get, true);
        } else if (preg_match('/^STEAM_[0-9]{1,2}:[0-1]:\d+$/', $link)) {
            $ex = explode(":", $link);
            $_s64 = $ex[2] * 2 + $ex[1] + '76561197960265728';
            $get = $this->CurlSend("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" . $_SAPIKEY . "&steamids=" . $_s64);
            $content = json_decode($get, true);
        } else if (preg_match('/^\[U:(.*)\:(.*)\]$/', $link, $match)) {
            if (!empty($match[2])) {
                $_s64 = $match[2] + '76561197960265728';
                $get = $this->CurlSend("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" . $_SAPIKEY . "&steamids=" . $_s64);
                $content = json_decode($get, true);
            } else {
                return $link;
            }
        }
        if (!empty($content)) {
            if (!empty($type)) {
                return con_steam64to32($content['response']['players'][0]['steamid']);
            } else {
                exit(trim(
                        json_encode([
                            'img' => $content['response']['players'][0]['avatarfull'],
                            'name' => htmlspecialchars($content['response']['players'][0]['personaname']),
                            'steam64' => $content['response']['players'][0]['steamid'],
                            'steam32' => con_steam64to32($content['response']['players'][0]['steamid'])
                        ])
                    ));
            }
        } else {
            if (!empty($type))
                return $link;
            else
                return false;
        }
    }

    # Пользовательские функции интерфейса
    public function LkOnPayment($post)
    {
        if (empty($post['gatewayPay']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ChangeGateway'), 'error');
        $Gateway = $this->LkGetGatewayOn($post['gatewayPay']);
        
        $post['steam'] = $this->LkLoadPlayerProfile($post['steam'], 2);
        if (empty($Gateway))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_GatewayOnNotEzist'), 'error');
        else if (empty($post['steam']))
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_EnterSteam'), 'error');
        if (!preg_match('/^STEAM_[0-9]{1,2}:[0-1]:\d+$/', $post['steam'])) {
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_SteamError'), 'error');
        } else if (empty($post['amount'])) {
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_EnterAmount'), 'error');
        } else if (!preg_match('/^[0-9]{1,5}.[0-9]{1,2}$/', $this->WM($post['amount']))) {
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_AmountError'), 'error');
        } else if ($post['amount'] < 5) {
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_AmountError1'), 'error');
        // } else if (empty($post['checkbox'])) {
        //     $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_СheckErrorSever'), 'error');
        } else if (!empty($post['promocode'])) {
            if (!preg_match('/^[A-z-0-9]{5,15}$/', $post['promocode']))
                $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_ErrorPromocode'), 'error');
            $this->checkPromo($post['promocode'], $post['steam']);
        }
        $this->LkNotExistGateway($post['gatewayPay']);
        $this->setPay($post);
    }

    protected function setPay($post)
    {
        $data = $this->LkGetGatewayOn($post['gatewayPay']);
        $order = time() % 100000;
        $desc = $this->Translate->get_translate_module_phrase('module_page_pay', '_OnPayUserDesc') . $post['steam'];
        $lk_sign = $this->Encoder($data[0]['id'] . ',' . $order . ',' . $post['amount'] . ',' . $post['steam']);
        switch ($post['gatewayPay']) {
			case 'cshost_liqpay':
				if (empty($data[0]['status'])) {
					$this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'Cshost Liqpay']), 'error');
				}

				$lk_sign = base64_encode($post['amount'].','.$post['steam']);

				$this->LKRegPay($order, $post, 'cshost_liqpay');
				$sign = hash('sha256', $lk_sign.'|'.$data[0]['shop_id'].'|'.$order.'|'.$data[0]['secret_key_1']);
				$this->message('<form  method="post" action="https://cshost.com.ua/cassa"><input name="userdata" value="'.$lk_sign.'"><input name="sum" value="'.$post['amount'].'"><input name="ps" value="liqpay"><input name="idpay" value="'.$order.'"><input name="idcassa" value="'.$data[0]['shop_id'].'"><input name="sign"  value="'.$sign.'"><input id="punsh" type="submit"></form>','');

				break;
			case 'cshost_p2p':
				if (empty($data[0]['status'])) {
					$this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'Cshost p2p']), 'error');
				}

				$lk_sign = base64_encode($post['amount'].','.$post['steam']);
				$timerCH = substr(time(), -4);
				$this->LKRegPay($order, $post, 'cshost_p2p');
				$sign = hash('sha256', $lk_sign.'|'.$data[0]['shop_id'].'|'.$order.'|'.$data[0]['secret_key_1']);
				$this->message('<form  method="post" action="https://cshost.com.ua/cassa"><input name="userdata" value="'.$lk_sign.'"><input name="sum" value="'.$post['amount'].'"><input name="ps" value="p2p"><input name="idpay" value="'.$order.'"><input name="timer" value="'.$timerCH.'"><input name="idcassa" value="'.$data[0]['shop_id'].'"><input name="sign"  value="'.$sign.'"><input id="punsh" type="submit"></form>','');

				break;
            case 'freekassa':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'FreeKassa']), 'error');

                $this->LKRegPay($order, $post, 'Freekassa');
                $sign = md5($data[0]['shop_id'] . ':' . $post['amount'] . ':' . $data[0]['secret_key_1'] . ':RUB:' . $order);
                $this->location('https://pay.freekassa.ru/?' . http_build_query([
                    'm' => $data[0]['shop_id'],
                    'oa' => $post['amount'],
                    'o' => $order,
                    's' => $sign,
                    'currency' => 'RUB',
                    'us_sign' => $lk_sign
                ]));
                break;
            case 'skinpay':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'SkinPay']), 'error');

                $this->LKRegPay($order, $post, 'SkinPay');
                function skinPaySign($q)
                {
                    $paramsString = '';
                    ksort($q);
                    foreach ($q as $key => $value) {
                        if ($key == 'sign') continue;
                        $paramsString .= $key . ':' . $value . ';';
                    }
                    return $paramsString;
                }
                $query = [
                    'orderid' => $order,
                    'key' => $data[0]['shop_id']
                ];
                $query['sign'] = hash_hmac('sha1', skinPaySign($query), $data[0]['secret_key_1']);
                $this->location('https://skinpay.com/deposit?' . http_build_query($query));
                break;
            case 'skinsback':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'SkinsBack']), 'error');

                $this->LKRegPay($order, $post, 'SkinsBack');
                function skinsBackSign($params)
                {
                    $paramsString = '';
                    ksort($params);
                    foreach($params AS $key => $value) {
                        if($key == 'sign') continue;
                        if(is_array($value)) { continue; }
                        $paramsString .= $key .':'. $value .';';
                    }
                    return $paramsString;
                }
                $apiUrl = 'https://skinsback.com/api.php';
                $query = [
                    'shopid' => $data[0]['shop_id'],
                    'order_id' => $order,
                    'method' => 'create',
                ];
                $query['sign'] = hash_hmac('sha1', skinsBackSign($query), $data[0]['secret_key_1']);

                $headers = array('Authorization: Bearer ' . $data[0]['secret_key_1']);
                $ch = curl_init($apiUrl);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($query));
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
                $responseData = json_decode($response, true);
                $this->location($responseData['url']);
                break;
            case 'centapp':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'CentAPP']), 'error');

                $this->LKRegPay($order, $post, 'CentAPP');
                $apiUrl = 'https://cent.app/api/v1/bill/create';
                $accessToken = $data[0]['secret_key_1'];
                $data = array(
                    'amount' => $post['amount'],
                    'description' => $desc,
                    'order_id' => $order,
                    'type' => 'normal',
                    'shop_id' => $data[0]['shop_id'],
                    'custom' => $lk_sign,
                    'currency_in' => 'RUB'
                );
                $headers = array('Authorization: Bearer ' . $accessToken);
                $ch = curl_init($apiUrl);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                $responseData = json_decode($response, true);
                $this->location($responseData['link_page_url']);
                curl_close($ch);
                break;
            case 'paypalych':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'PayPalych']), 'error');

                $this->LKRegPay($order, $post, 'PayPalych');
                $apiUrl = 'https://paypalych.com/api/v1/bill/create';
                $accessToken = $data[0]['secret_key_1'];
                $data = array(
                    'amount' => $post['amount'],
                    'description' => $desc,
                    'order_id' => $order,
                    'type' => 'normal',
                    'shop_id' => $data[0]['shop_id'],
                    'custom' => $lk_sign,
                    'currency_in' => 'RUB'
                );
                $headers = array('Authorization: Bearer ' . $accessToken);
                $ch = curl_init($apiUrl);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                $responseData = json_decode($response, true);
                $this->location($responseData['link_page_url']);
                curl_close($ch);
                break;
            case 'yandexmoney':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'YandexMoney']), 'error');

                $this->LKRegPay($order, $post, 'YandexMoney');
                $this->message(
                    '<form method="POST" action="https://yoomoney.ru/quickpay/confirm.xml"> 
    				<input name="receiver" value="' .
                        $data[0]['shop_id'] .
                        '"><input name="quickpay-form" value="shop"><input name="targets" value="' .
                        $desc .
                        '"> 
    				<input name="paymentType" value="PC"><input name="label" value="' .
                        $lk_sign .
                        '"> 
    				<input name="sum" value="' .
                        $post['amount'] .
                        '"><input type="hidden" name="successUrl" value="https://ck-gaming.com/processing"' .
                        $this->https() .
                        get_url(2) .
                        '">
						<input id="punsh" type="submit"></form>',
                    ''
                );
                break;
            case 'yandexmoneycard':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'YandexMoneyCard']), 'error');

                $this->LKRegPay($order, $post, 'YandexMoneyCard');
                $this->message(
                    '<form method="POST" action="https://yoomoney.ru/quickpay/confirm.xml"> 
    				<input name="receiver" value="' .
                        $data[0]['shop_id'] .
                        '"><input name="quickpay-form" value="shop"><input name="targets" value="' .
                        $desc .
                        '"> 
    				<input name="paymentType" value="AC"><input name="label" value="' .
                        $lk_sign .
                        '"> 
    				<input name="sum" value="' .
                        $this->WM($post['amount']) .
                        '"><input type="hidden" name="successUrl" value="https://ck-gaming.com/processing"' .
                        $this->https() .
                        get_url(2) .
                        '">
						<input id="punsh" type="submit"></form>',
                    ''
                );
                break;
            case 'paypal':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'PayPal']), 'error');

                $this->LKRegPay($order, $post, 'PayPal');
                $this->message(
                    '<form action="https://www.paypal.com/cgi-bin/webscr" method="post"><input type="hidden" name="cmd" value="_xclick">
									  <input type="hidden" name="business" value="' .
                        $data[0]['shop_id'] .
                        '"><input type="hidden" name="notify_url" value="' .
                        $this->https() .
                        get_url(2) .
                        'pay/?gateway=paypal"><input type="hidden" name="item_name" value="' .
                        $desc .
                        '"><input type="hidden" name="item_number" value="' .
                        $lk_sign .
                        '">
									  <input type="hidden" name="amount" value="' .
                        $post['amount'] .
                        '"><input type="hidden" name="currency_code" value="' .
                        $data[0]['secret_key_1'] .
                        '"><input type="hidden" name="successUrl" value="https://ck-gaming.com/processing"' .
                        $this->https() .
                        get_url(2) .
                        '">
						<input id="punsh" type="submit" name="submit"></form>',
                    ''
                );
                break;
            case 'qiwi':

                if (empty($data[0]['status']))
                    $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'Qiwi']), 'error');

                $this->LKRegPay($order, $post, 'Qiwi');
                $this->message(
                    '<form action="https://oplata.qiwi.com/create" method="GET"><input type="hidden" name="publicKey" value="' .
                        $data[0]['secret_key_1'] .
                        '"><input type="hidden" name="comment" value="' .
                        $desc .
                        '"><input type="hidden" name="account" value="' .
                        $lk_sign .
                        '"><input type="hidden" name="amount" value="' .
                        $post['amount'] .
                        '"><input type="hidden" name="successUrl" value="https://ck-gaming.com/processing"' .
                        $this->https() .
                        get_url(2) .
                        '">
						<input id="punsh" type="submit" name="submit"></form>',
                    ''
                );
                break;

            case 'foxypay':

                    $checkInDB = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk` WHERE `auth` = :auth LIMIT 1",
                    [
                        "auth" => $_SESSION['steamid32']
                    ]);


                    if(count($checkInDB) == 0) 
                    {
                        $this->db->query('lk', 0, 0, "INSERT INTO `lk` (`auth`, `name`, `cash`, `all_cash`) VALUES(:steamid32, :username, :cash, :allcash);", 
                        [
                            "steamid32" => $_SESSION['steamid32'],
                            "username" => 'RanomPlayer#'.time(),
                            "cash" => 0,
                            "allcash" => 0
                        ]);
                    }


        

                    if (empty($data[0]['status']) || $data[0]['status'] == 0)
                    {
                        $this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_lk_impulse', '_GatwayOff'), ['name' => 'FoxyPay']), 'error');
                    }

                    //Check in db user


                    $this->LKRegPay($order, $post, 'FoxyPay');


                    $foxy = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pay_service` WHERE `id` = :id LIMIT 1",
                    [
                        "id" => 11
                    ]);

                    $foxyToken = $foxy[0]["secret_key_1"];

                    $promocode = "no_promocode";

                    if(isset($post["promocode"]) && !empty($post["promocode"]))
                    {
                        $promocode = $post["promocode"];
                    }

                    $post = [
                        "amount" => (int)$post['amount'] * 100,
                        "description" => 'Пополнение баланса',
                        "webhook_url" => $this->https() . '//' . $_SERVER["SERVER_NAME"].'/lk/?foxycallback',
                        "success_url" => $this->https() . '//' . $_SERVER["SERVER_NAME"].'/lk/#success',
                        "fail_url" => $this->https() . '//' . $_SERVER["SERVER_NAME"].'/lk/',
                        "info" => $order . ":" . $promocode
                    ];
                    
                    $post = http_build_query($post);
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, "https://foxypay.net/api/payment");
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'token: ' . $foxyToken
                    ]);
                    
                    $response = curl_exec($ch);
                    
                    curl_close($ch);
                    
                    $response = json_decode($response);
                    
                    if(isset($response->redirect_url))
                    {
                        $this->location($response->redirect_url);
                    } else {
                        $this->message($response->err, 'error');
                        //$this->message(LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_GatwayOff'), ['name' => 'FoxyPay']), 'error');
                    }

                break;
            default:
            
                $this->message('Error', 'error');
                break;
            
        }
    }

    public function checkCallback()
    {
        
        if(isset($_GET["foxycallback"]))
        {
            
            ob_clean();

            $data = file_get_contents('php://input');
            $data = json_decode($data);

            $paycode = $data->code;
            $info = explode(":", $data->info);
            $order = $info[0];
            $promocode = $info[1];

            $this->db->query('lk', 0, 0, "UPDATE `lk_pays` SET `pay_status` = :pay_status WHERE `pay_order` = :pay_order LIMIT 1",
            [
                "pay_status" => 1,
                "pay_order" => $order
            ]);

            $r = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pays` WHERE `pay_order` = :pay_order LIMIT 1",
            [
                "pay_order" => $order
            ]);

            $sum = $r[0]["pay_summ"];
            $auth = $r[0]["pay_auth"];

            if(strpos($auth, "STEAM_0") === 0)
            {
                $auth2 = str_replace("STEAM_0", "STEAM_1", $auth);
            }
            
            if(strpos($auth, "STEAM_1") === 0)
            {
                $auth2 = str_replace("STEAM_1", "STEAM_0", $auth);
            }

            if($promocode != "no_promocode")
            {
                $param = [
                    'code' 	=> $promocode
                ];
                $promoCode = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_promocodes` WHERE `code` = :code LIMIT 1", $param);
                
                if (count($promoCode) > 0)
                {
                    $this->db->query('lk', 0, 0, "UPDATE `lk_promocodes` SET `attempts` = `attempts` - 1 WHERE `code` = :code LIMIT 1", $param);
                    $bonus = ($sum / 100) * $promoCode[0]['percent'];
                    $sum = $bonus + $sum;

                    //$this->LkAddLog('_SetPromo', ['course' => $this->Translate->get_translate_module_phrase('module_page_pay', '_AmountCourse'), 'numberpay' => $paycode, 'promocode' => $promocode, 'amount' => $bonus, 'gateway' => 'FoxyPay']);
                    
                }
            }

            $this->db->query('lk', 0, 0, "UPDATE `lk` SET `cash` = `cash` + :cash WHERE `auth` = :auth OR `auth` = :auth2",
            [
                "cash" => $sum,
                "auth" => $auth,
                "auth2" => $auth2,
            ]);

            $this->Notifications->SendNotification($auth, "Поповнення", "Ваш баланс поповнено на <a>" . $sum . " ₴</a>", "/lk/", "pay");
            $this->Notifications->SendNotification($auth2, "Поповнення", "Ваш баланс поповнено на <a>" . $sum . " ₴</a>", "/lk/", "pay");

            exit;
        }
    }

    protected function checkPromo($promo, $sid)
    {
        $param = [
            'code'  => $promo
        ];
        $codeInfo = $this->db->queryAll('lk', 0, 0, "SELECT * FROM lk_promocodes WHERE code = :code", $param);
        if (empty($codeInfo)) {
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_NotFoundPromo'), 'error');
        } else if ($codeInfo[0]['attempts'] <= 0) {
            $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_NoLimitPromo'), 'error');
        } else if ($codeInfo[0]['auth1']) {
            preg_match('/:[0-9]{1}:\d+/i', $sid, $auth);
            $params = [
                'code'  => $promo,
                'auth'  => '%' . $auth[0] . '%'
            ];
            $userPromo = $this->db->queryAll('lk', 0, 0, "SELECT `pay_promo` FROM `lk_pays` WHERE `pay_promo` = :code AND `pay_status` = 1 AND `pay_auth` LIKE :auth LIMIT 1", $params);
            if ($userPromo)
                $this->message($this->Translate->get_translate_module_phrase('module_page_pay', '_YouUsePromo'), 'error');
        }
    }

    public function LkCalculatePromo($promo, $steam, $amount)
    {
        $steam = $this->LkLoadPlayerProfile($steam, 2);
        if ($amount < 0.1) {
            exit(trim(
                    json_encode([
                        'result' =>
                        '<div class="code_error">' .
                            LangValReplace($this->Translate->get_translate_module_phrase('module_page_pay', '_MinAmount'), ['course' => $this->Translate->get_translate_module_phrase('module_page_pay', '_AmountCourse')]) .
                            '</div>',
                    ])
                ));
        } else if (!preg_match('/^STEAM_[0-9]{1,2}:[0-1]:\d+$/', $steam)) {
            exit(trim(
                    json_encode([
                        'result' => $this->Translate->get_translate_module_phrase('module_page_pay', '_SteamError'),
                    ])
                ));
        } else if ($amount >= 10 && !empty($steam)) {
            $param = ['code' => $promo];
            $codeInfo = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_promocodes` WHERE `code` = :code", $param);
            if (empty($codeInfo)) {
                exit(trim(
                        json_encode([
                            'result' => $this->Translate->get_translate_module_phrase('module_page_pay', '_NotFoundPromo'),
                        ])
                    ));
            } else if ($codeInfo[0]['attempts'] <= 0) {
                exit(trim(
                        json_encode([
                            'result' => $this->Translate->get_translate_module_phrase('module_page_pay', '_NoLimitPromo'),
                        ])
                    ));
            } else if ($codeInfo[0]['auth1']) {
                preg_match('/:[0-9]{1}:\d+/i', $steam, $auth);
                $params = [
                    'code'  => $promo,
                    'auth'  => '%' . $auth[0] . '%'
                ];
                $userPromo = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pays` WHERE `pay_promo` = :code AND `pay_status` = 1 AND `pay_auth` LIKE :auth LIMIT 1", $params);
                if ($userPromo) {
                    exit(trim(
                            json_encode([
                                'result' => $this->Translate->get_translate_module_phrase('module_page_pay', '_YouUsePromo'),
                            ])
                        ));
                }
            }
            $bonus = ($amount / 100) * $codeInfo[0]['percent'];
            $newAmount = addslashes($bonus + $amount);
            if ($newAmount >= 1000000)
                $formattedAmount = number_format($newAmount / 1000000, 2) . " кк";
            else if ($newAmount >= 1000)
                $formattedAmount = number_format($newAmount / 1000, 2) . " к";
            else
                $formattedAmount = $newAmount;
            exit(trim(json_encode(["success_promo" => $formattedAmount . " ₴ (+" . $codeInfo[0]['percent'] . "%)"])));
        }
    }

    public function https()
    {
        if (!empty($_SERVER['HTTPS']) && 'off' !== strtolower($_SERVER['HTTPS']))
            return 'https:';
        else
            return 'http:';
    }

    protected function LKRegPay($order, $post, $system)
    {
        $params = [
            'order'     => $order,
            'auth'      => $post['steam'],
            'summ'      => $post['amount'],
            'data'      => date('d.m.Y \в H:i:s'),
            'system'    => $system,
            'promo'     => $post['promocode']
        ];
        $this->db->query(
            'lk',
            0,
            0,
            "INSERT INTO `lk_pays` (`pay_order`, `pay_auth`, `pay_summ`, `pay_data`, `pay_system`, `pay_promo`, `pay_status`) VALUES(:order, :auth, :summ, :data, :system, :promo, 0)",
            $params
        );
    }

    protected function Encoder($string)
    {
        $return = base64_encode(base64_encode($string));
        return $return;
    }

    protected function WM($summ)
    {
        $ita = explode('.', $summ);
        if (COUNT($ita) == 1)
            $summa = $ita[0] . '.00';
        else
            $summa = $summ;
        return $summa;
    }

    protected function LkConvertGatewayId($gateway)
    {
        $array = [
            'freekassa' => 1,
            'yandexmoney' => 2,
            'yandexmoneycard' => 2,
            'paypal' => 3,
            'qiwi' => 4,
            'centapp' => 5,
            'skinpay' => 6,
            'skinsback' => 7,
            'paypalych' => 8,
			'cshost_liqpay'	=> 9,
			'cshost_p2p'	=> 10,
            'foxypay' => 11
        ];
        return $array[$gateway];
    }

    protected function LkConvertGatewayString($id)
    {
        $array = [
            1 => 'freekassa',
            2 => 'yandexmoney',
            2 => 'yandexmoneycard',
            3 => 'paypal',
            4 => 'qiwi',
            5 => 'centapp',
            6 => 'skinpay',
            7 => 'skinsback',
            8 => 'paypalych',
			9 => 'cshost_liqpay',
			10 => 'cshost_p2p',
            11 => 'foxypay',
        ];
        return $array[$id];
    }

    protected function message($text, $status)
    {
        exit(trim(
                json_encode([
                    'text' => $text,
                    'status' => $status,
                ])
            ));
    }

    protected function location($url)
    {
        exit(trim(json_encode(['location' => $url])));
    }

    public function LKChart()
    {
        $cashSYS = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_pays` WHERE `pay_status` = 1  ORDER BY `pay_id` ASC");
        if (!empty($cashSYS)) {
            $fff = json_encode($cashSYS);
            $json = json_decode($fff, true);
            $mount_name = [
                '12' => "Декабрь",
                '11' => "Ноябрь",
                '10' => "Октябрь",
                '09' => "Сентябрь",
                '08' => "Август",
                '07' => "Июль",
                '06' => "Июнь",
                '05' => "Май",
                '03' => "Март",
                '02' => "февраль",
                '01' => "Январь",
            ];

            $c_arr = sizeof($json);
            for ($i = 0; $i < $c_arr; $i++) {
                $mount = explode(".", $json[$i]['pay_data']);
                $pay = $json[$i]['pay_system'];
                $oldYear = date("Y") - 1;
                if (substr($mount[2], 0, -9) == $oldYear)
                    $end[$oldYear][$pay] += $json[$i]['pay_summ'];
                else
                    $end[$mount_name[$mount[1]]][$pay] += $json[$i]['pay_summ'];
            }
            echo "anychart.onDocumentReady(function() {
					anychart.theme('darkEarth');
					var chart = anychart.line();
					chart.animation(true);
					chart.legend().enabled(true).fontSize(12).padding([0, 0, 0, 0]);
					chart.crosshair().enabled(true).yLabel(false).yStroke(null);
					chart.tooltip().positionMode('point');
	  				chart.xAxis().labels().padding(1);
					var dataSet = anychart.data.set([";

            foreach ($end as $key => $value) {
                echo "['$key'";
                foreach ($value as $key2 => $val2) {
                    echo ", $val2";
                }
                echo ', 0],';
            }
            echo "]);";
            $i = 1;
            foreach ($end as $key => $value) {
                foreach ($value as $key2 => $val) {
                    if ($one[$key2] != $key2) {
                        echo "
							seriesData_$i = dataSet.mapAs({'x': 0,'value': $i});
				  			series$key2 = chart.line(seriesData_$i);
							series$key2.name('$key2');
							series$key2.hovered().markers().enabled(true).type('circle').size(2);
							series$key2.tooltip().position('right').anchor('left-center').offsetX(5).offsetY(5);";
                        $one[$key2] = $key2;
                        $i++;
                    }
                }
            }
            echo "chart.container('containerChart');
					chart.draw();});";
        }
    }

    public function CurlSend($url)
    {
        $c = curl_init($url);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        $url = curl_exec($c);
        return $url;
    }

    public function SearchUser($post)
    {

        $searchTrim = trim($post);
        $Steam = trim($this->LkLoadPlayerProfile($searchTrim, true));

        if (empty($searchTrim))
            $this->message('Строка поиска пустая', 'error');

        $param = [
            'search' =>     "%$searchTrim%"
        ];

        if ($this->db->db_data['lk'][0]['mod'] == 1) {
            $infoUser = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk` WHERE `auth` LIKE :search ORDER BY `all_cash` DESC LIMIT 0,20", $param);
            if (empty($infoUser))
                $infoUser = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk` WHERE `name` LIKE :search ORDER BY `all_cash` DESC LIMIT 0,20", $param);
        } else if ($this->db->db_data['lk'][0]['mod'] == 2) {
            $infoUser = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_system` WHERE `auth` LIKE :search ORDER BY `all_money` DESC LIMIT 0,20", $param);
            if (empty($infoUser))
                $infoUser = $this->db->queryAll('lk', 0, 0, "SELECT * FROM `lk_system` WHERE `name` LIKE :search ORDER BY `all_money` DESC LIMIT 0,20", $param);
        }

        $_SESSION['search'] = $infoUser;
        $this->location('?section=search');
    }
}
